# SMM Site - Social Media Marketing Panel

## Overview
A web application for social media marketing services built with FastAPI (Python). Users can purchase social media services like views, likes, and followers through various payment providers.

## Current State
- Project successfully imported and running on Replit
- FastAPI server running on port 5000
- All dependencies installed

## Project Structure
```
smm_site/
├── app/
│   ├── main.py         # FastAPI application entry point
│   ├── config.py       # Configuration (API keys)
│   ├── database.py     # Database utilities
│   ├── models/         # Data models
│   │   └── order.py    # Order model
│   ├── routes/         # API endpoints
│   │   ├── api.py      # API routes
│   │   └── site.py     # Website routes
│   ├── services/       # External service integrations
│   │   ├── vingboost.py    # VingBoost SMM provider
│   │   ├── crystalpay.py   # CrystalPay payment
│   │   └── cryptobot.py    # CryptoBot payment
│   ├── static/         # CSS, JS, images
│   └── templates/      # Jinja2 HTML templates
└── requirements.txt
```

## How to Run
The application runs automatically via the configured workflow:
```
cd smm_site && python -c "import uvicorn; uvicorn.run('app.main:app', host='0.0.0.0', port=5000, reload=True)"
```

## Technologies
- **Framework**: FastAPI
- **Template Engine**: Jinja2
- **Server**: Uvicorn
- **Language**: Python 3.11

## Key Endpoints
- `/` - Homepage with services
- `/orders` - Order management
- `/statistics` - Statistics page
- `/create_order` - Create new order (POST)
- `/create_invoice` - Create payment invoice (POST)
- `/health` - Health check endpoint

## Recent Changes
- 2026-01-02: Initial import to Replit, configured for port 5000

## User Preferences
- None recorded yet
