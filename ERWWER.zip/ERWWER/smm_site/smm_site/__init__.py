"""Compatibility package to support import path `smm_site`.
This package is intentionally minimal: it allows scripts expecting
`smm_site.app.main:app` to import from the existing `app` package.
"""

__all__ = []
